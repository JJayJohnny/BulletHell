#pragma once

#define SCREEN_WIDTH	1280
#define SCREEN_HEIGHT	720 
#define LEVEL_WIDTH 2700
#define LEVEL_HEIGHT 2400

#define CZARNY SDL_MapRGB(screen->format, 0x00, 0x00, 0x00)
#define ZIELONY SDL_MapRGB(screen->format, 0x00, 0xFF, 0x00)
#define CZERWONY SDL_MapRGB(screen->format, 0xFF, 0x00, 0x00)
#define NIEBIESKI SDL_MapRGB(screen->format, 0x11, 0x11, 0xCC)